/**
 * @(#)ConnectionProvider.java	Oct 22, 2007
 */

import java.sql.Connection;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

/**
 * Retrieves a connection from the DataSource pointed by the JNDI name.
 * 
 * @author $Author: vijaykandy $
 * @version $Revision: 1.1 $
 */
public class ConnectionProvider {
	private static Logger logger = Logger.getLogger(ConnectionProvider.class);

	/**
	 * Retrieves connection from the DataSource located at <code>jndiName</code>
	 * 
	 * @param jndiName
	 * @return
	 * @throws DataAccessException
	 */
	public static Connection getConnection(String jndiName) throws DataAccessException {
		Connection connection = null;
		try {
			Context context = new InitialContext();
			DataSource ds = (DataSource) context.lookup(jndiName);
			connection = ds.getConnection();
		} catch (ClassCastException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (NamingException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (Exception e) {
			logger.debug(e);
			throw new DataAccessException(e);
		}

		return connection;
	}

	/**
	 * Retrieves connection after applying properties set in the
	 * <code>DataSourceSupplement</code> instance.
	 * 
	 * @param jndiName
	 * @param supplement
	 * @return
	 * @throws NamingException
	 */
	public static Connection getConnection(String jndiName, DataSourceCustomizer supplement) throws NamingException {
		Connection connection = null;
		connection = supplement.getConnection(jndiName);
		return connection;
	}

	/**
	 * Retrieves connection after applying default properties set in the
	 * <code>supplementClass</code> instance.
	 * 
	 * @param jndiName
	 * @param supplementClass
	 * @return
	 * @throws NamingException
	 */
	public static Connection getConnection(String jndiName, String supplementClass) throws NamingException {
		DataSourceCustomizer supplement = (DataSourceCustomizer) ReflectionUtil.newInstance(supplementClass, null);
		return supplement.getConnection(jndiName);
	}

	/**
	 * Retrieves connection after applying properties passed as argument.
	 * 
	 * @param jndiName
	 * @param supplementClass
	 * @return
	 * @throws NamingException
	 */
	public static Connection getConnection(String jndiName, String supplementClass, Map map) throws NamingException {
		Object args[] = new Object[] { map };
		DataSourceCustomizer supplement = (DataSourceCustomizer) ReflectionUtil.newInstance(supplementClass, args);
		return supplement.getConnection(jndiName);
	}
}
