/**
 * @(#)DataAccessException.java	May 22, 2008
 */

import java.sql.SQLException;

import org.apache.log4j.Logger;

/**
 * A wrapper to SQLExceptions
 * 
 * @author $Author: vijaykandy $
 * @version $Revision: 1.1 $
 */
public class DataAccessException extends Exception {
	private static Logger logger = Logger.getLogger(DataAccessException.class);

	public DataAccessException(Exception e) {
		super(e);
	}

	public DataAccessException(String shortMsg, Exception e) {
		super(shortMsg, e);
	}

	public DataAccessException(SQLException e) {
		super(e);
		logger.debug("SQL State: " + e.getSQLState() + ", Error code:" + e.getErrorCode());
	}

	public DataAccessException(String shortMsg) {
		super(shortMsg);
	}

	public DataAccessException(String shortMsg, SQLException e) {
		super(shortMsg, e);
		logger.debug("SQL State: " + e.getSQLState() + ", Error code:" + e.getErrorCode());
	}

}
