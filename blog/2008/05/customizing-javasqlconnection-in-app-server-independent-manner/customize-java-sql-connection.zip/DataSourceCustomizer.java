/**
 * @(#)DataSourceSupplement.java	Oct 19, 2007
 */

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;

/**
 * Changes attributes of a <code>DataSource</code> at run-time.
 * 
 * @author $Author: vijaykandy $
 * @version $Revision: 1.2 $
 */
public abstract class DataSourceCustomizer {
	public static final String ISOLATION_LEVEL = "ISOLATION_LEVEL";
	
	protected HashMap map = new HashMap();

	public DataSourceCustomizer() {
	}

	public DataSourceCustomizer(Map map) {
		this.map.putAll(map);
	}

	public Object getValue(String key) {
		return map.get(key);
	}

	public void setValue(String key, Object value) {
		map.put(key, value);
	}

	/**
	 * Applies any properties in the map to the underlying DataSource.
	 * 
	 */
	public abstract Connection getConnection(String jndiName) throws NamingException;
}
