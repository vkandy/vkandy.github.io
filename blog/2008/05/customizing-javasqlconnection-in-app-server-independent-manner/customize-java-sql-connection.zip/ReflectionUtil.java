/**
 * @(#)ReflectionUtil.java	May 22, 2008
 */

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;

/**
 * A collections of useful reflection methods.
 * 
 * @author $Author: vijaykandy $
 * @version $Revision: 1.1 $
 */
public final class ReflectionUtil {

	private static Logger logger = Logger.getLogger(ReflectionUtil.class);

	public static Object invokeMethod(Method method, Object target, Object[] args) {
		try {
			return method.invoke(target, args);
		} catch (IllegalArgumentException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (InvocationTargetException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Creates a new instance of <code>className</code> with the given
	 * arguments.
	 * 
	 * @param className
	 * @param args
	 * @return
	 */
	public static Object newInstance(Class clazz, Object[] args) {
		try {
			Class argTypes[] = null;
			if (args != null) {
				argTypes = new Class[args.length];
				for (int i = 0; i < args.length; i++) {
					argTypes[i] = args[i].getClass();
				}
			}

			Constructor constructor = clazz.getConstructor(argTypes);
			return constructor.newInstance(args);
		} catch (SecurityException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (IllegalArgumentException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (NoSuchMethodException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (InstantiationException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (InvocationTargetException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Creates a new instance of <code>className</code> with the given
	 * arguments.
	 * 
	 * @param className
	 * @param args
	 * @return
	 */
	public static Object newInstance(String className, Object[] args) {
		try {
			Class argTypes[] = null;
			Class clazz = ReflectionUtil.loadClass(className);
			if (args != null) {
				argTypes = new Class[args.length];
				for (int i = 0; i < args.length; i++) {
					argTypes[i] = args[i].getClass();
				}
			}

			Constructor constructor = clazz.getConstructor(argTypes);
			return constructor.newInstance(args);
		} catch (SecurityException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (IllegalArgumentException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (NoSuchMethodException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (InstantiationException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		} catch (InvocationTargetException e) {
			logger.debug(e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * Loads a class from the classloader of this class or the context class
	 * loader.
	 * 
	 * @return the loaded class object
	 * @throws ClassNotFoundException
	 */
	public static Class loadClass(String className) throws ClassNotFoundException {
		ClassLoader cl = ReflectionUtil.getClassLoader();
		return cl.loadClass(className);
	}

	/**
	 * Returns the class loader for the class. If that is null, the context
	 * class loader for the current thread is returned.
	 * 
	 * @return
	 */
	public static ClassLoader getClassLoader() {
		ClassLoader cl = ReflectionUtil.class.getClassLoader();
		if (cl == null) {
			cl = Thread.currentThread().getContextClassLoader();
		}
		return cl;
	}
}
