/**
 * @(#)Test.java	May 27, 2008
 */
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

/**
 * Tests a connection. Preferred way would be to use a properties file that can
 * be read by <code>Class.getInputStream()</code> and dynamically set the
 * customizer class property.
 * 
 * @author $Author: vijaykandy $
 * @version $Revision: 1.1 $
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		String jndiName = "jdbc/MyDS";
		String customizerClass = "WebSphereDataSourceCustomizer";

		// Set isolation level to Connection.TRANSACTION_READ_COMMITTED
		Map properties = new HashMap();
		properties.put("ISOLATION_LEVEL", new Integer(2));

		Connection connection = ConnectionProvider.getConnection(jndiName, customizerClass, properties);
	}
}
