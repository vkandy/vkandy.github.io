/**
 * @(#)WebSphereDataSourceSupplement.java	May 22, 2007
 */

import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * Adds/overrides properties of a <code>WSDataSource</code> class. This is to
 * be used with WebSphere 5.1 version. This class uses reflection and WebSphere
 * APIs to set isolation level. See <a
 * href="http://publib.boulder.ibm.com/infocenter/wasinfo/v5r1//index.jsp?topic=/com.ibm.websphere.base.doc/info/aes/ae/rdat_extiapi.html">
 * IBM Example</a>.
 * 
 * @author $Author: vijaykandy $
 * @version $Revision: 1.1 $
 */
public class WebSphereDataSourceCustomizer extends DataSourceCustomizer {

	protected Class WSDataSourceClass;

	protected Class JDBCConnectionSpecClass;

	protected Class WSRRAFactoryClass;

	protected Method createJDBCConnectionSpecMethod;

	protected Method getConnectionMethod;

	protected Method setTransactionIsolationMethod;

	public WebSphereDataSourceCustomizer() {
		init();
	}

	public WebSphereDataSourceCustomizer(Map map) {
		super(map);
		init();
	}

	public WebSphereDataSourceCustomizer(HashMap map) {
		super(map);
		init();
	}

	private void init() {
		ClassLoader classLoader = ReflectionUtil.getClassLoader();
		try {
			WSDataSourceClass = classLoader.loadClass("com.ibm.websphere.rsadapter.WSDataSource");
			JDBCConnectionSpecClass = classLoader.loadClass("com.ibm.websphere.rsadapter.JDBCConnectionSpec");
			WSRRAFactoryClass = classLoader.loadClass("com.ibm.websphere.rsadapter.WSRRAFactory");
			createJDBCConnectionSpecMethod = WSRRAFactoryClass.getMethod("createJDBCConnectionSpec", null);
			getConnectionMethod = WSDataSourceClass.getMethod("getConnection", new Class[] { JDBCConnectionSpecClass });

			Class args[] = new Class[] { int.class };
			setTransactionIsolationMethod = JDBCConnectionSpecClass.getMethod("setTransactionIsolation", args);
		} catch (SecurityException e) {
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		} catch (NoSuchMethodException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * The following logic is executed using reflection:
	 * 
	 * <pre>
	 * int level = ... a level defined by the client ...
	 * JDBCConnectionSpec jdbcConnectionSpec = WSRRAFactory.createJDBCConnectionSpec();
	 * jdbcConnectionSpec.setTransactionIsolation(level);
	 * Connection connection = ((WSDataSource) datasource).getConnection(jdbcConnectionSpec);
	 * </pre>
	 * 
	 * @throws NamingException
	 */
	public Connection getConnection(String jndiName) throws NamingException {

		// Lookup the DataSource located at the given location
		Context context = new InitialContext();
		DataSource ds = (DataSource) context.lookup(jndiName);

		// createJDBCConnectionSpec() is a static method
		Object jdbcConnectionSpec = ReflectionUtil.invokeMethod(createJDBCConnectionSpecMethod, null, null);

		// Set the isolation level
		if (map.containsKey(ISOLATION_LEVEL)) {
			Integer isolationLevel = (Integer) map.get(ISOLATION_LEVEL);
			Object args[] = new Object[] { isolationLevel };
			ReflectionUtil.invokeMethod(setTransactionIsolationMethod, jdbcConnectionSpec, args);
		}

		Object args[] = new Object[] { jdbcConnectionSpec };
		Connection connection = (Connection) ReflectionUtil.invokeMethod(getConnectionMethod, ds, args);
		return connection;
	}

}
