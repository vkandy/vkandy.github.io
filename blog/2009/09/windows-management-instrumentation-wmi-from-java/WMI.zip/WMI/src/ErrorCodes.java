/*
 * @(#) ServiceErrors.java  Sep 23, 2009
 */
import java.util.HashMap;
import java.util.Map;

/**
 * Error codes.
 * 
 * @version $Revision: $
 * @author $Author: $
 */
public final class ErrorCodes {

	public static final Map<Integer, String> SERVICE_ERRORS = new HashMap<Integer, String>();

	static {
		SERVICE_ERRORS.put(0, "Success");
		SERVICE_ERRORS.put(1, "Not Supported");
		SERVICE_ERRORS.put(2, "Access Denied");
		SERVICE_ERRORS.put(3, "Dependent Services Running");
		SERVICE_ERRORS.put(4, "Invalid Service Control");
		SERVICE_ERRORS.put(5, "Service Cannot Accept Control");
		SERVICE_ERRORS.put(6, "Service Not Active");
		SERVICE_ERRORS.put(7, "Service Request timeout");
		SERVICE_ERRORS.put(8, "Unknown Failure");
		SERVICE_ERRORS.put(9, "Path Not Found");
		SERVICE_ERRORS.put(10, "Service Already Stopped");
		SERVICE_ERRORS.put(11, "Service Database Locked");
		SERVICE_ERRORS.put(12, "Service Dependency Deleted");
		SERVICE_ERRORS.put(13, "Service Dependency Failure");
		SERVICE_ERRORS.put(14, "Service Disabled");
		SERVICE_ERRORS.put(15, "Service Logon Failed");
		SERVICE_ERRORS.put(16, "Service Marked For Deletion");
		SERVICE_ERRORS.put(17, "Service No Thread");
		SERVICE_ERRORS.put(18, "Status Circular Dependency");
		SERVICE_ERRORS.put(19, "Status Duplicate Name");
		SERVICE_ERRORS.put(20, "Status - Invalid Name");
		SERVICE_ERRORS.put(21, "Status - Invalid Parameter");
		SERVICE_ERRORS.put(22, "Status - Invalid Service Account");
		SERVICE_ERRORS.put(23, "Status - Service Exists");
		SERVICE_ERRORS.put(24, "Service Already Paused");
	}
}
