import static org.jinterop.dcom.core.JIProgId.valueOf;
import static org.jinterop.dcom.impls.JIObjectFactory.narrowObject;
import static org.jinterop.dcom.impls.automation.IJIDispatch.IID;

import java.util.logging.Level;

import org.jinterop.dcom.common.JISystem;
import org.jinterop.dcom.core.IJIComObject;
import org.jinterop.dcom.core.JIArray;
import org.jinterop.dcom.core.JIComServer;
import org.jinterop.dcom.core.JISession;
import org.jinterop.dcom.core.JIString;
import org.jinterop.dcom.core.JIVariant;
import org.jinterop.dcom.impls.automation.IJIDispatch;
import org.jinterop.dcom.impls.automation.IJIEnumVariant;

/**
 * Retrieves all instances of a given class and prints their text
 * representation.
 * 
 * @version $Revision: $
 * @author $Author: $
 */
public class PrintInstances {

	private static final String CLASS_NAME = "Win32_Process";
	
	/**
	 * Main.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String domain = "";
		String hostname = "";
		String username = "";
		String password = "";

		JISession dcomSession = null;

		try {
			dcomSession = init(domain, username, password);
			JIComServer comServer = new JIComServer(valueOf("WbemScripting.SWbemLocator"), hostname, dcomSession);
			IJIDispatch wbemLocator = (IJIDispatch) narrowObject(comServer.createInstance().queryInterface(IID));

			Object[] params = new Object[] { 
					new JIString(hostname), 
					new JIString("ROOT\\CIMV2"),
					JIVariant.OPTIONAL_PARAM(), 
					JIVariant.OPTIONAL_PARAM(), 
					JIVariant.OPTIONAL_PARAM(),
					JIVariant.OPTIONAL_PARAM(), 
					new Integer(0), 
					JIVariant.OPTIONAL_PARAM() 
			};
			JIVariant results[] = wbemLocator.callMethodA("ConnectServer", params);
			IJIDispatch wbemServices = (IJIDispatch) narrowObject(results[0].getObjectAsComObject());

			params = new Object[] { 
					new JIString(CLASS_NAME), 
					new Integer(0), 
					JIVariant.OPTIONAL_PARAM() 
			};
			JIVariant[] servicesSet = wbemServices.callMethodA("InstancesOf", params);
			IJIDispatch wbemObjectSet = (IJIDispatch) narrowObject(servicesSet[0].getObjectAsComObject());

			JIVariant newEnumvariant = wbemObjectSet.get("_NewEnum");
			IJIComObject object2 = newEnumvariant.getObjectAsComObject();
			IJIEnumVariant enumVARIANT = (IJIEnumVariant) narrowObject(object2.queryInterface(IJIEnumVariant.IID));

			JIVariant countVariant = wbemObjectSet.get("Count");
			int numberOfServices = countVariant.getObjectAsInt();

			for (int i = 0; i < numberOfServices; i++) {
				Object[] elements = enumVARIANT.next(1);
				JIArray aJIArray = (JIArray) elements[0];

				JIVariant[] array = (JIVariant[]) aJIArray.getArrayInstance();
				for (JIVariant variant : array) {
					IJIDispatch wbemObjectDispatch = (IJIDispatch) narrowObject(variant.getObjectAsComObject());
					
					// Use other methods to start and stop services. For now we'll just print as text.
					JIVariant[] v = wbemObjectDispatch.callMethodA("GetObjectText_", new Object[] { 1 });
					System.out.println(v[0].getObjectAsString().getString());					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (dcomSession != null) {
				try {
					JISession.destroySession(dcomSession);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		}
	}
	
	/**
	 * Retrieve a session.
	 * 
	 * @param domain
	 * @param user
	 * @param pass
	 * @return
	 * @throws Exception
	 */
	private static JISession init(String domain, String user, String pass) throws Exception {
		JISystem.getLogger().setLevel(Level.OFF);
		JISystem.setAutoRegisteration(true);

		JISession dcomSession = JISession.createSession(domain, user, pass);
		dcomSession.useSessionSecurity(true);
		return dcomSession;
	}	
}
