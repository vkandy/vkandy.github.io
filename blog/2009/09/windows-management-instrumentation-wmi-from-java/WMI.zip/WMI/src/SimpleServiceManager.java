import static org.jinterop.dcom.core.JIProgId.valueOf;
import static org.jinterop.dcom.impls.JIObjectFactory.narrowObject;
import static org.jinterop.dcom.impls.automation.IJIDispatch.IID;

import java.util.logging.Level;

import org.jinterop.dcom.common.JISystem;
import org.jinterop.dcom.core.IJIComObject;
import org.jinterop.dcom.core.JIArray;
import org.jinterop.dcom.core.JIComServer;
import org.jinterop.dcom.core.JISession;
import org.jinterop.dcom.core.JIString;
import org.jinterop.dcom.core.JIVariant;
import org.jinterop.dcom.impls.automation.IJIDispatch;
import org.jinterop.dcom.impls.automation.IJIEnumVariant;

/**
 * Manages Windows services using WMI API.
 * 
 * @version $Revision: $
 * @author $Author: $
 */
public class SimpleServiceManager {

	private static final int STOP = 0;

	private static final int START = 1;

	/**
	 * Driver.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		String domain = "";
		String hostname = "";
		String username = "";
		String password = "";

		// We'll start 'Event Log' service.
		// Note: Display name is "Event Log" where as service name is "Eventlog"
		SimpleServiceManager manager = new SimpleServiceManager();
		manager.stop(domain, hostname, username, password, "Eventlog");
	}

	/**
	 * Starts a given service if its stopped.
	 * 
	 * @param domain
	 * @param hostname
	 * @param username
	 * @param password
	 * @param serviceName
	 */
	public void start(String domain, String hostname, String username, String password, String serviceName) {
		manageService(domain, hostname, username, password, serviceName, START);
	}

	/**
	 * Stops a given service if its running.
	 * 
	 * @param domain
	 * @param hostname
	 * @param username
	 * @param password
	 * @param serviceName
	 */
	public void stop(String domain, String hostname, String username, String password, String serviceName) {
		manageService(domain, hostname, username, password, serviceName, STOP);
	}

	/**
	 * Starts/Stops a given service by connecting to the machine identified by
	 * hostname.
	 * 
	 * <p/>
	 * 
	 * <strong>NOTE:</strong> serviceName is the display name of the service.
	 * 
	 * @param domain
	 * @param hostname
	 * @param username
	 * @param password
	 * @param serviceName
	 * @param action
	 */
	public void manageService(String domain, String hostname, String username, String password, String serviceName,
			int action) {

		if (action != START && action != STOP) {
			return;
		}
		
		JISession dcomSession = null;
		try {
			dcomSession = init(domain, username, password);
			JIComServer comServer = new JIComServer(valueOf("WbemScripting.SWbemLocator"), hostname, dcomSession);
			IJIDispatch wbemLocator = (IJIDispatch) narrowObject(comServer.createInstance().queryInterface(IID));

			Object[] params = new Object[] { 
					new JIString(hostname), 
					new JIString("ROOT\\CIMV2"),
					JIVariant.OPTIONAL_PARAM(), 
					JIVariant.OPTIONAL_PARAM(), 
					JIVariant.OPTIONAL_PARAM(),
					JIVariant.OPTIONAL_PARAM(), 
					new Integer(0), 
					JIVariant.OPTIONAL_PARAM() 
			};
			JIVariant results[] = wbemLocator.callMethodA("ConnectServer", params);

			IJIDispatch wbemServices = (IJIDispatch) narrowObject(results[0].getObjectAsComObject());

			final int RETURN_IMMEDIATE = 0x10;
			final int FORWARD_ONLY = 0x20;
			params = new Object[] { 
					new JIString("SELECT * FROM Win32_Service WHERE Name = '" + serviceName + "'"),
					JIVariant.OPTIONAL_PARAM(), 
					new JIVariant(new Integer(RETURN_IMMEDIATE + FORWARD_ONLY)) 
			};
			JIVariant[] servicesSet = wbemServices.callMethodA("ExecQuery", params);
			IJIDispatch wbemObjectSet = (IJIDispatch) narrowObject(servicesSet[0].getObjectAsComObject());

			JIVariant newEnumvariant = wbemObjectSet.get("_NewEnum");
			IJIComObject enumComObject = newEnumvariant.getObjectAsComObject();
			IJIEnumVariant enumVariant = (IJIEnumVariant) narrowObject(enumComObject.queryInterface(IJIEnumVariant.IID));

			Object[] elements = enumVariant.next(1);
			JIArray aJIArray = (JIArray) elements[0];

			JIVariant[] array = (JIVariant[]) aJIArray.getArrayInstance();
			for (JIVariant variant : array) {
				IJIDispatch wbemObjectDispatch = (IJIDispatch) narrowObject(variant.getObjectAsComObject());

				// Print object as text. Optional - comment if not needed
				JIVariant[] v = wbemObjectDispatch.callMethodA("GetObjectText_", new Object[] { 1 });
				System.out.println(v[0].getObjectAsString().getString());
				
				// Start or Stop the servie
				String methodToInvoke = (action == START) ? "StartService" : "StopService";
				JIVariant returnStatus = wbemObjectDispatch.callMethodA(methodToInvoke);

				// Print out the meaning out return code
				System.out.println(ErrorCodes.SERVICE_ERRORS.get(returnStatus.getObjectAsInt()));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (dcomSession != null) {
				try {
					JISession.destroySession(dcomSession);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		}
	}

	/**
	 * Retrieve a session.
	 * 
	 * @param domain
	 * @param user
	 * @param pass
	 * @return
	 * @throws Exception
	 */
	private static JISession init(String domain, String user, String pass) throws Exception {
		JISystem.getLogger().setLevel(Level.OFF);
		JISystem.setAutoRegisteration(true);

		JISession dcomSession = JISession.createSession(domain, user, pass);
		dcomSession.useSessionSecurity(true);
		return dcomSession;
	}
}
