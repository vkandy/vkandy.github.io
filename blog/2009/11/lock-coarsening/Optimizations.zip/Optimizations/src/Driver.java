
public class Driver {

	public static void main(String[] args) {
		FavoriteChars demo = new FavoriteChars();
		for (int i = 0; i < 100000; i++) {
			System.err.println(demo.myFavorites());
		}
	}
}
