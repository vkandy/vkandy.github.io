public class FavoriteChars {

	private final char[] VOWELS = new char[] { 'a', 'e', 'i', 'o', 'u' };

	public char[] myFavorites() {
		char first = getVowel(0);
		char second = getVowel(1);
		char third = getVowel(2);
		return new char[] { first, second, third };
	}

	public synchronized char getVowel(int index) {
		return VOWELS[index];
	}
}
