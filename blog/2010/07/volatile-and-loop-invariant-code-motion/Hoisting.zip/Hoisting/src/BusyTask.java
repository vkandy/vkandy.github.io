public class BusyTask implements Runnable {
	private volatile boolean stop;

	public void shutdown() {
		this.stop = true;
	}

	public void run() {
		while (!stop) {
		}
		System.out.println("Busy task stopped");
	}
}

/*

http://xiao-feng.blogspot.com/2008/01/gc-safe-point-and-safe-region.html

http://blogs.sun.com/fatcatair/entry/safepoints


*/