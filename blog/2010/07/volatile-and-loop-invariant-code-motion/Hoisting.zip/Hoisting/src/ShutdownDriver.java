public class ShutdownDriver {
	
	public static void main(String[] s) {
		BusyTask task = new BusyTask();
		new Thread(task).start();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		task.shutdown();		
		System.out.println("BusyTask should stop now.");
	}
}
